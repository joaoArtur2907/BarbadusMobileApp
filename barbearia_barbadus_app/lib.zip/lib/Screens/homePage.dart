import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class homePage extends StatefulWidget {
  const homePage({super.key});
  @override
  State<homePage> createState() => _HomePageState();
}

class _HomePageState extends State<homePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF2F2D2E),

      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[

            // Título "PRODUTOS" (centralizado com padding)
            Padding(
              padding: EdgeInsets.only(top: 60, bottom: 20, ),
              child: Center(
                child: RichText(
                  text: TextSpan(
                    text: 'PRODUTOS',
                    style: TextStyle(
                      color: Color(0xFFFCFFFC),
                      fontWeight: FontWeight.bold,
                      fontSize: 45,
                    ),
                  ),
                ),
              ),
            ),

            // grid dos produtos
            GridView.builder(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              padding: EdgeInsets.symmetric(horizontal: 20),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 15,
                mainAxisSpacing: 15,
                childAspectRatio: 0.8,
              ),
              itemCount: 4,
              itemBuilder: (context, index){
                return Container(
                  decoration: BoxDecoration(
                    color: Color(0xFFFCFFFC),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // Container para a imagem do produto
                      Container(
                        height: 120,
                        padding: EdgeInsets.all(10),
                        child: Image.asset(
                          'lib/Assets/shampoo.png',
                          fit: BoxFit.contain, // Mantém proporções sem cortar
                          width: 100, // Largura fixa
                          height: 100, // Altura fixa
                          // Opções adicionais:
                          // scale: 0.8, // Redimensiona a imagem
                          // alignment: Alignment.center, // Alinhamento
                          // repeat: ImageRepeat.noRepeat, // Repetição
                        ),
                      ),
                      SizedBox(height: 5),
                      Text(
                        'BIO EXTRATUS',
                        style: TextStyle(
                          color: Color(0xFF2F2D2E),
                          fontSize: 18,
                        ),
                      ),
                      SizedBox(height: 10),
                      TextButton(onPressed: () {},
                          child: Text(
                            'SAIBA MAIS',
                            style: TextStyle(color: Color(0xFF2F2D2E)),
                          ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

