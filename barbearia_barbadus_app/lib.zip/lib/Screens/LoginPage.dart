import 'package:barbearia_barbadus_app/Screens/homePage.dart';
import 'package:barbearia_barbadus_app/main.dart';
import 'package:flutter/material.dart';


class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}
class _LoginPageState extends State<LoginPage> {

  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      backgroundColor: Color(0xFF2F2D2E),
      body: SingleChildScrollView(

        child: Form(
          key: _formKey,
          child: Column(

            children: <Widget>[
              // imagem
              Padding(
                padding: const EdgeInsets.only(top: 60.0, bottom: 10),
                child: Center(
                  child: Container(
                    width: 200,
                    height: 150,
                    child: Icon(Icons.icecream_sharp, size: 80),

                  ),
                ),
              ),

              Container(
                margin: EdgeInsets.symmetric(horizontal: 105, vertical: 10),
                padding: EdgeInsets.only(left: 25,right: 25, top: 40, bottom: 25),
                width: 500,
                decoration: BoxDecoration(
                  color: Color(0xFFFCFFFC),
                  borderRadius: BorderRadius.circular(10),

                ),
              child: Column(

                // concertar layouts

                children: <Widget>[
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      RichText(
                        text: TextSpan(

                          text: 'Nome de usuario ',
                          style: TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.normal,
                            fontSize: 22,


                          ),
                        ),
                      ),
                    ],
                  ),

                  TextFormField(
                    validator: (valor) {
                      if (valor == null || valor.isEmpty) {
                        return 'nome de usuário';
                      }
                      return null;
                    },
                    decoration: const InputDecoration(
                      border: OutlineInputBorder(
                        borderSide: BorderSide(width: 2.0, color: Colors.black87),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(width: 2.0, color: Colors.black38),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(width: 2.0, color: Colors.black),
                      ),
                      hintText: 'Seu nome',
                    ),
                  ),
                  SizedBox(height: 20),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      RichText(
                        text: TextSpan(

                          text: 'Senha',
                          style: TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.normal,
                            fontSize: 22,

                          ),
                        ),
                      ),
                    ],
                  ),

                  TextFormField(
                    obscureText: true,

                    validator: (valor) {
                      if (valor == null || valor.isEmpty) {
                        return 'senha';
                      }
                      return null;
                    },
                    decoration: const InputDecoration(
                      border: OutlineInputBorder(
                        borderSide: BorderSide(width: 2.0, color: Colors.black87),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(width: 2.0, color: Colors.black38),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(width: 2.0, color: Colors.black),
                      ),
                      hintText: '********',
                    ),
                  ),
                  // botao de login
                  SizedBox(height: 20,),
                  Container(

                    height: 50,
                    width: 220,
                    decoration: BoxDecoration(
                        color: Color(0xFF09BC8A), borderRadius: BorderRadius.circular(5)),
                    child: TextButton(
                      onPressed: (){
                        if(_formKey.currentState!.validate()){
                          Navigator.push(context, MaterialPageRoute(builder: (_) => homePage()));
                        }
                      },
                      child: const Text(
                        'entrar',
                        style: TextStyle(color: Colors.white, fontSize: 25),
                      ),
                    ),
                  ),
                ],

              ),
              ),





              const SizedBox(
                height: 90,
              ),
              // criar sua conta
              // TextButton(onPressed: (){},
              //   child: const Text("Crie sua conta", style: TextStyle(color: Colors.blue),),
              // )
            ],
          ),
        ),
      ),
    );
  }
}



